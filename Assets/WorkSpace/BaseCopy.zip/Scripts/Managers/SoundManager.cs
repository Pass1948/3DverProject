using UnityEngine;
using UnityEngine.Audio;
using System.Collections;
using System.Collections.Generic;

public class SoundManager : MonoBehaviour
{
    private AudioMixer mixer;
    private readonly string masterVolumeParam = "Master";
    private readonly string bgmVolumeParam = "BGM";
    private readonly string sfxVolumeParam = "SFX";
    private AudioSource bgmSource;
    private AudioSource sfxSource;
    private SoundDataSO currentBGM;
    private Coroutine fadeCoroutine;
    private SoundData soundDB;

    // �̸� �� ������ ����
    private readonly Dictionary<string, SoundDataSO> soundDict = new();

    // (�ɼ�) ���� BGM ����: ���̸� �� soundName
    // string ���� string �� �����ؼ� �ǹ̰� ũ�� ������?
    private Dictionary<string, string> sceneBGMMapping = new()
    {
        { "StartScene", "StartBGM" },
        { "MainScene",  "MainBGM"  },
        { "PlayScene",  "PlayBGM"  },
    };

    private void Awake()
    {
        InitializeDB();  // DB�� ��ųʸ��� ����
        // �ʿ��ϸ� ���⼭ �� �̺�Ʈ ���� �� �� ���� �� PlaySceneBGM ȣ��
    }

    // ===================== DB �ʱ�ȭ =====================
    private void InitializeDB()
    {
        mixer = GameManager.Resource.Load<AudioMixer>(GamePath.Sound + "AudioMixer");
        bgmSource = GameManager.Resource.Instantiate<AudioSource>(GamePath.Sound+"BGM", this.transform);
        sfxSource = GameManager.Resource.Instantiate<AudioSource>(GamePath.Sound + "SFX", this.transform);

        // db �� ��������� ���� ������Ʈ �����ϰ� �ִٸ� �޸� ������ Ŀ�� -> ���� ��巹���� �̿��ϸ� ���� ����
        soundDB = GameManager.Resource.Load<SoundData>(GamePath.Data+"SoundData");

        soundDict.Clear();

        if (soundDB == null || soundDB.soundInfo == null || soundDB.soundInfo.Count == 0)
        {
            Debug.LogWarning("[SoundManager] SoundDB �������. SoundData SO�� �Ҵ��ϰ� �׸��� �߰��ϼ���.", this);
            return;
        }

        foreach (var d in soundDB.soundInfo)
        {
            if (d == null) continue;
            if (string.IsNullOrWhiteSpace(d.soundName))
            {
                Debug.LogWarning("[SoundManager] soundName�� ����ִ� �׸��� �ֽ��ϴ�.", this);
                continue;
            }
            if (!soundDict.TryAdd(d.soundName, d))
            {
                Debug.LogWarning($"[SoundManager] �ߺ� soundName: {d.soundName}. ù �׸� ����մϴ�.", this);
            }
        }
    }

    // ===================== ���� BGM =====================
    public void PlaySceneBGM(string sceneName)
    {
        if (sceneBGMMapping != null && sceneBGMMapping.TryGetValue(sceneName, out string bgmName))
            PlayBGM(bgmName);
    }

    // ===================== Static ���� =====================
    public static void OnPlaySound(string soundName)
    {
        GameManager.Sound.PlaySound(soundName);
    }
    public static void OnPlaySound(SoundDataSO soundData)
    {
        GameManager.Sound.PlaySound(soundData);
    }

    // ===================== �̸�/�����ͷ� ��� =====================
    public void PlaySound(string soundName)
    {
        if (TryGet(soundName, out var data))
            PlaySound(data);
        else
            Debug.LogWarning($"[SoundManager] ���� �̵��: {soundName}", this);
    }

    public void PlaySound(SoundDataSO data)
    {
        if (data == null) return;

        if (data.soundType == SoundType.BGM) PlayBGM(data);
        else PlaySFX(data);
    }

    // ===================== BGM =====================
    public void PlayBGM(string soundName, bool loop = true)
    {
        if (TryGet(soundName, out var data))
            PlayBGM(data, loop);
        else
            Debug.LogWarning($"[SoundManager] BGM �̵��: {soundName}", this);
    }

    public void PlayBGM(SoundDataSO data, bool loop = true)
    {
        if (data == null || data.soundType != SoundType.BGM) return;

        var clip = GetAudioClip(data);
        if (clip == null)
        {
            Debug.LogWarning($"[SoundManager] BGM Ŭ�� ����: {data.soundName}", this);
            return;
        }

        bgmSource.loop = loop;

        // ���� Ŭ���̸� �Ѿ�� ���δ� ����. ������ �����ϰ� ��� ����.
        if (bgmSource.clip == clip && bgmSource.isPlaying)
        {
            bgmSource.volume = data.volume;
            currentBGM = data;
            return;
        }

        bgmSource.clip = clip;
        bgmSource.volume = data.volume;
        bgmSource.Play();
        currentBGM = data;
    }

    // ===================== SFX =====================
    public void PlaySFX(string soundName)
    {
        if (TryGet(soundName, out var data)) PlaySFX(data);
        else Debug.LogWarning($"[SoundManager] SFX �̵��: {soundName}", this);
    }

    public void PlaySFX(SoundDataSO data)
    {
        if (data == null || data.soundType != SoundType.SFX) return;

        var clip = GetAudioClip(data);
        if (clip == null)
        {
            Debug.LogWarning($"[SoundManager] SFX Ŭ�� ����: {data.soundName}", this);
            return;
        }

        sfxSource.volume = data.volume;
        sfxSource.PlayOneShot(clip);
    }

    // ===================== ����/��Ʈ =====================
    public static void SetMute(SoundType type, bool isOn)
    {
        if (type == SoundType.BGM) SetBGMMute(isOn);
        else SetSFXMute(isOn);
    }

    public static void SetBGMMute(bool isOn)
    {
        if (GameManager.Sound?.bgmSource == null) return;
        GameManager.Sound.bgmSource.mute = isOn;
    }

    public static void SetSFXMute(bool isOn)
    {
        if (GameManager.Sound?.sfxSource == null) return;
        GameManager.Sound.sfxSource.mute = isOn;
    }

    public void SetVolume(VolumeType type, float volume)
    {
        string param = type == VolumeType.Master ? masterVolumeParam : type == VolumeType.BGM ? bgmVolumeParam : sfxVolumeParam;
        float volumeDB = (volume <= 0.0001f) ? -80f : Mathf.Log10(Mathf.Clamp01(volume)) * 20f;
        mixer.SetFloat(param, volumeDB);
    }

    public float GetVolume(VolumeType type)
    {
        string param = type == VolumeType.Master ? masterVolumeParam :
                       type == VolumeType.BGM ? bgmVolumeParam : sfxVolumeParam;

        if (mixer != null && mixer.GetFloat(param, out float db))
            return Mathf.Pow(10f, db / 20f);

        return 1f;
    }

    public void ResetVolumes()
    {
        SetVolume(VolumeType.Master, 1f);
        SetVolume(VolumeType.BGM, 1f);
        SetVolume(VolumeType.SFX, 1f);
    }

    // ===================== ���̵� =====================
    public void FadeOutBGM(float duration)
    {
        if (currentBGM == null || bgmSource == null) return;
        if (fadeCoroutine != null) StopCoroutine(fadeCoroutine);
        fadeCoroutine = StartCoroutine(FadeVolumeCoroutine(bgmSource.volume, 0f, duration));
    }

    public void FadeInBGM(float duration)
    {
        if (currentBGM == null || bgmSource == null) return;
        if (fadeCoroutine != null) StopCoroutine(fadeCoroutine);
        // target�� currentBGM.volume��
        fadeCoroutine = StartCoroutine(FadeVolumeCoroutine(bgmSource.volume, currentBGM.volume, duration));
    }

    private System.Collections.IEnumerator FadeVolumeCoroutine(float from, float to, float duration)
    {
        if (duration <= 0f) { bgmSource.volume = to; yield break; }

        float t = 0f;
        while (t < duration)
        {
            t += Time.unscaledDeltaTime;
            bgmSource.volume = Mathf.Lerp(from, to, t / duration);
            yield return null;
        }
        bgmSource.volume = to;
    }

    // ===================== ��ƿ =====================
    private bool TryGet(string soundName, out SoundDataSO data)
    {
        if (string.IsNullOrWhiteSpace(soundName))
        {
            data = null;
            return false;
        }

        if (soundDict.TryGetValue(soundName, out data) && data != null)
            return true;

        // DB�� ���ŵǾ��� �� ������ �� �� ����� �õ�(�ɼ�)
        InitializeDB();
        return soundDict.TryGetValue(soundName, out data) && data != null;
    }

    private AudioClip GetRandomClip(SoundDataSO data)
    {
        if (data == null || data.audioClips == null || data.audioClips.Length == 0) return null;
        if (data.audioClips.Length == 1) return data.audioClips[0];
        int idx = Random.Range(0, data.audioClips.Length);
        return data.audioClips[idx];
    }

    private AudioClip GetAudioClip(SoundDataSO data)
    {
        AudioClip a = GameManager.Resource.Load<AudioClip>(GamePath.Sound + data.soundName);
        if (data == null || data.soundName == null || a == null) return null;
        return a;
    }
}
